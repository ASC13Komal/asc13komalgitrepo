package com.example.hcms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HcmsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
