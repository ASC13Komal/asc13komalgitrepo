package com.example.hcms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HcmsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(HcmsBackendApplication.class, args);
	}

}
